import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css'],
  standalone: true,
  imports: [MatInputModule, MatButtonModule, FormsModule, MatFormFieldModule], // Importing Material Form Field Module for form field styling.
})
export class AddTaskComponent {
  taskText: string = '';

  // Emit an event when a new task is added
  @Output() addTask = new EventEmitter<string>();

  constructor() {}

  // Method to handle the form submission
  addTaskHandler() {
    if (this.taskText.trim()) {
      // Emit the task text to the parent component
      this.addTask.emit(this.taskText);
      // Clear the input field
      this.taskText = '';
    }
  }
}
